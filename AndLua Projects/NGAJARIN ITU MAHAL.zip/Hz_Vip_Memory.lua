
-- JOIN : T.ME/ANDLUAOFFICIAL
-- PLEASE SHARE WITH CREDITS

function HzNoRoot(Hz_B,HackZoneMod)
Hz_C=activity.getLuaDir(Hz_B)
os.execute("chmod 777 "..Hz_C)
Runtime.getRuntime().exec(""..Hz_C)
MD提示(HackZoneMod,"#6f003e7c","#ffffffff","9","45")
end
--
function HzRoot(Hz_B,HackZoneMod)
Hz_C=activity.getLuaDir(Hz_B)
os.execute("su -c chmod 777 "..Hz_C)
Runtime.getRuntime().exec("su -c "..Hz_C)
MD提示(HackZoneMod,"#6f003e7c","#ffffffff","9","45")
end


--


function hz1.OnCheckedChangeListener()
if hz1.checked then
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture1_on","Active")
else
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture1_off","Deactive")
end
end

function hz2.OnCheckedChangeListener()
if hz2.checked then
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture2_on","Active")
else
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture2_off","Deactive")
end
end

function hz3.OnCheckedChangeListener()
if hz3.checked then
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture3_on","Active")
else
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture3_off","Deactive")
end
end

function hz4.OnCheckedChangeListener()
if hz4.checked then
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture4_on","Active")
else
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture4_off","Deactive")
end
end

function hz5.OnCheckedChangeListener()
if hz5.checked then
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture5_on","Active")
else
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/fiture5_off","Deactive")
end
end



























