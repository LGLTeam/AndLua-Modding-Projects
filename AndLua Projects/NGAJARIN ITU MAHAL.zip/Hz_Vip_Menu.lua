minlay={
LinearLayout;
layout_width="40dp";
layout_height="40dp";
{
ImageView;
layout_width="60dp";
src="icon.png";
id="Win_minWindow";
layout_height="60dp";
};
};

winlay={
LinearLayout,
layout_width="-1",
layout_height="-1",
background="transparent",
{
CardView,
id="win_mainview",
layout_width="60%w", 
layout_height="30%h";
layout_margin="5dp",
background="#ff000000";
CardElevation="5dp",
{
LinearLayout;
orientation="vertical";
layout_width="fill_parent";
background="transparent",
{
LinearLayout;
layout_width="fill_parent";
background="transparent";
{
LinearLayout;
orientation="horizontal";
layout_height="fill";
layout_width="-1";
gravity="center_horizontal|center_vertical";
background="transparent",
{
ImageView,
translationX="-20dp";
layout_height="5.5%h";
layout_width="10%w";
colorFilter="#ffffffff";
src="Vip_Hz_Mods/Hz_Vip_Min.png",
onClick="changeWindow",
},

{
LinearLayout;
orientation="vertical";
gravity="center_horizontal|center_vertical";
{
TextView;
text="PLEASE ENTER YOUR NAME";
id="win_move1",
layout_width="29%w",
ellipsize="marquee";
focusableInTouchMode=true;
focusable=true;
singleLine=true;
textSize="16dp";
textColor="#ffffff";
},
{
TextView;
text="Game Name - Version";
id="win_move2",
textSize="10dp";
textColor="#ffffff";
},
};

{
ImageView,
translationX="20dp";
layout_height="5.5%h";
layout_width="10%w";
colorFilter="#ffffffff";
src="Vip_Hz_Mods/Hz_Vip_Close.png",
onClick="close",
},
};
};
{
LinearLayout;
orientation="horizontal";
layout_height="20";
layout_width="-1";
};
{
PageView,
id="pg",
layout_width="fill",
layout_height="fill",
pages={
{
LinearLayout;
orientation="vertical";
{
ScrollView;
layout_width="fill_parent";
layout_height="fill_parent",
layout_gravity="center_horizontal";
{
LinearLayout;
layout_height="-1";
layout_width="-1";
orientation="vertical";
{
LinearLayout;
id="_drawer_header";
layout_height="-2";
layout_width="-1";
orientation="vertical";
{
LinearLayout;
layout_height="-1";
layout_width="-1";
orientation="vertical";
{
LinearLayout;
orientation="horizontal";
layout_height="20";
layout_width="-1";
};

{
Switch;
layout_width="-1";
layout_width="-1";
id="hz1";
textColor="#FFFFFF";
text="   FITURE 1";
textSize="10dp";
};
{
Switch;
layout_width="-1";
id="hz2";
textColor="#FFFFFF";
text="   FITURE 2";
textSize="10dp";
};
{
Switch;
layout_width="-1";
id="hz3";
textColor="#FFFFFF";
text="   FITURE 3";
textSize="10dp";
};
{
Switch;
layout_width="-1";
id="hz4";
textColor="#FFFFFF";
text="   FITURE 4";
textSize="10dp";
};
{
Switch;
layout_width="-1";
id="hz5";
textColor="#FFFFFF";
text="   FITURE 5";
textSize="10dp";
};








};
};
};
};
};
};
};
};
};
}