appname="LAYOUT BY SANDI HZ"
appver="1.0"
packagename="t.me.andluaofficial" 
theme="Theme_DeviceDefault_Light_NoActionBar_Fullscreen"
developer="Sandi"
description="Created By : Sandi"
debugmode=true
user_permission={
  "ACCESS_NETWORK_STATE",
  "CHANGE_WIFI_STATE",
  "INTERNET",
  "READ_EXTERNAL_STORAGE",
  "READ_PHONE_STATE",
  "SYSTEM_ALERT_WINDOW",
  "WRITE_EXTERNAL_STORAGE",
  "WRITE_SETTINGS"
}
