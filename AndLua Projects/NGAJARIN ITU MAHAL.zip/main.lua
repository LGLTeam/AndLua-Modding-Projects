require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "AndLua"
import "http"
import "android.content.Context"
import "android.content.Intent"
import "android.provider.Settings"
import "android.net.Uri"
import "android.content.pm.PackageManager"
import "android.graphics.Typeface"
import "Hz_Vip_Menu"
import "Hz_Vip_Ly"
载入页面(Hz_Vip_Ly)

HzNoRootZ=activity.getSystemService(Context.WINDOW_SERVICE)
HasFocus=false
WmHz =WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then WmHz.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
else WmHz.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
import "android.graphics.PixelFormat"
WmHz.format =PixelFormat.RGBA_8888
WmHz.flags=WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
WmHz.gravity = Gravity.LEFT| Gravity.TOP
WmHz.x = 333
WmHz.y = 333
WmHz.width = WindowManager.LayoutParams.WRAP_CONTENT
WmHz.height = WindowManager.LayoutParams.WRAP_CONTENT
mainWindow = loadlayout(winlay)
minWindow = loadlayout(minlay)
function close(v)
HasLaunch = false
HzNoRootZ.removeView(mainWindow)
end
isMax=true
function changeWindow()
if isMax==false then
isMax=true
HzNoRootZ.removeView(minWindow)
HzNoRootZ.addView(mainWindow,WmHz)
else
isMax=false
HzNoRootZ.removeView(mainWindow)
HzNoRootZ.addView(minWindow,WmHz)
end end
function Win_minWindow.onClick(v) changeWindow() end
function Win_minWindow.OnTouchListener(v,event)
if event.getAction()==MotionEvent.ACTION_DOWN then
firstX=event.getRawX()
firstY=event.getRawY()
wmX=WmHz.x
wmY=WmHz.y
elseif event.getAction()==MotionEvent.ACTION_MOVE then
WmHz.x=wmX+(event.getRawX()-firstX)
WmHz.y=wmY+(event.getRawY()-firstY)
HzNoRootZ.updateViewLayout(minWindow,WmHz)
elseif event.getAction()==MotionEvent.ACTION_UP then
end return false end
function win_move1.OnTouchListener(v,event)
if event.getAction()==MotionEvent.ACTION_DOWN then
firstX=event.getRawX()
firstY=event.getRawY()
wmX=WmHz.x
wmY=WmHz.y
elseif event.getAction()==MotionEvent.ACTION_MOVE then
WmHz.x=wmX+(event.getRawX()-firstX)
WmHz.y=wmY+(event.getRawY()-firstY)
HzNoRootZ.updateViewLayout(mainWindow,WmHz)
elseif event.getAction()==MotionEvent.ACTION_UP then
end return true end
function win_move2.OnTouchListener(v,event)
if event.getAction()==MotionEvent.ACTION_DOWN then
firstX=event.getRawX()
firstY=event.getRawY()
wmX=WmHz.x
wmY=WmHz.y
elseif event.getAction()==MotionEvent.ACTION_MOVE then
WmHz.x=wmX+(event.getRawX()-firstX)
WmHz.y=wmY+(event.getRawY()-firstY)
HzNoRootZ.updateViewLayout(mainWindow,WmHz)
elseif event.getAction()==MotionEvent.ACTION_UP then
end return true end
pg.addOnPageChangeListener{
onPageScrolled=function(a,b,c)
end,
onPageSelected=function(page)
end,
onPageScrollStateChanged=function(state)
end,}

showhack.onClick=function() 
if HasLaunch==true then return else
if Settings.canDrawOverlays(activity) then else intent=Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
intent.setData(Uri.parse("package:" .. this.getPackageName()));  this.startActivity(intent); end HasLaunch=true
local ret={pcall(function() HzNoRootZ.addView(mainWindow,WmHz) end)}
if ret[1]==false then end end import "java.io.*" file,err=io.open("/data/data/t.me.andluaofficial/files/HzVipMemory.lua")
if err==nil then 打开app("t.me.andluaofficial") else end end

function startgame.onClick()
this.startActivity(activity.getPackageManager().getLaunchIntentForPackage("com.dts.freefireth"));
end

function about.onClick()
activity.newActivity("Hz_Vip_About")
activity.finish()
end

function CircleButton(view,InsideColor,radiu,InsideColor1)
import "android.graphics.drawable.GradientDrawable"
drawable = GradientDrawable()
drawable.setShape(GradientDrawable.RECTANGLE)
drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
drawable.setColor(InsideColor)
drawable.setStroke(3, InsideColor1)
view.setBackgroundDrawable(drawable)
end
CircleButton(win_mainview,0x3f000000,0,0xffffffff)
CircleButton(showhack,0x3f000000,0,0xfff800ff)
CircleButton(startgame,0x3f000000,0,0xfff800ff)
CircleButton(about,0x3f000000,0,0xffffffff)


win_move1.setTypeface(Typeface.DEFAULT_BOLD)

import "Hz_Vip_Memory"







