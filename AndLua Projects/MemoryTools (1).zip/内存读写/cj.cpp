#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
//killGG();
getRoot(argv);
PACKAGENAME *bm="com.tencent.tmgp.pubgmhd";
BypassGameSafe();
SetSearchRange(B_BAD);//设置搜索内存范围
SetTextColor(COLOR_SKY_BLUE);//设置文字颜色
puts("开始内存搜索...");
MemorySearch(bm,"541343815",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"671236122",12,&gs,DWORD);
MemoryOffset(bm,"274677786",20,&gs,DWORD);
MemoryOffset(bm,"95",-12,&gs,DWORD);
MemoryOffset(bm,"1670152217",-16,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("透视第一步...");
MemoryWrite(bm,"120",-4,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"1008981770",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"-2147483648",4,&gs,DWORD);
MemoryOffset(bm,"1060205080",-4,&gs,DWORD);
MemoryOffset(bm,"1047920112",-8,&gs,DWORD);
MemoryOffset(bm,"1065353216",-16,&gs,DWORD);
MemoryOffset(bm,"30",-164,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("透视第二步...");
MemoryWrite(bm,"120",-28,FLOAT);
puts("修改完成");
ClearResults();


puts("开始内存搜索...");
MemorySearch(bm,"1008981770",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"-2147483648",4,&gs,DWORD);
MemoryOffset(bm,"1060205080",-4,&gs,DWORD);
MemoryOffset(bm,"1047920112",-8,&gs,DWORD);
MemoryOffset(bm,"1065353216",-16,&gs,DWORD);
MemoryOffset(bm,"30",-140,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("透视第三步...");
MemoryWrite(bm,"120",-28,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"286785536",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1080035331",4,&gs,DWORD);
MemoryOffset(bm,"200983",8,&gs,DWORD);
MemoryOffset(bm,"537133058",-12,&gs,DWORD);
MemoryOffset(bm,"1",-16,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("上色...");
MemoryWrite(bm,"5",-20,FLOAT);
puts("修改完成");
ClearResults();
}