#include "MemoryTools.h"
int main(int argc,char **argv)
{
killGG();
int gs;//用来存储数据个数
void *jg;
PACKAGENAME *bm="com.tencent.tmgp.sgame";//软件包名
//注意这里要用指针,就是那个*号,不可以去掉

BypassGameSafe();
SetSearchRange(B_BAD);
puts("开始内存搜索...");
MemorySearch(bm,"3",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"-528220160",8,&gs,FLOAT);
MemoryOffset(bm,"-315782390",48,&gs,FLOAT);
MemoryOffset(bm,"-509591552",60,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("午后...");
MemoryWrite(bm,"0",-8,FLOAT);
puts("修改完成");
ClearResults();
}