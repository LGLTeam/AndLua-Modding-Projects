Must know
 The plug-in is only for technical exchanges, please do not use it for commercial and illegal purposes, such as legal disputes have nothing to do with me
 The plug-in is only for technical exchanges, please do not use it for commercial and illegal purposes, such as legal disputes have nothing to do with me
 The plug-in is only for technical exchanges, please do not use it for commercial and illegal purposes, such as legal disputes have nothing to do with me
 This memory plug-in can completely pass CD detection!
 This memory plug-in can completely pass CD detection!
 This memory plug-in can completely pass CD detection!

 XMemory plugin developed by XX

 2.1 Update log:
 1. Fixed the problem of reporting errors when continuously turned on
 2. Fixed the problem that the type of reading value function has no effect
 3. Added detection of whether the user is compatible with this plugin. Incompatibility will limit the memory reading function
 4. Fix some bugs

 2.2 Update log:
 1. Continue to fix the error report when continuously turned on
 2. Fully solve the crash problem

--[[

The following is a tutorial:


Import memory modification module
 Step 1: Copy XMemory.lua to the project main directory
 Step 2: Open main.lua and add at the beginning

require "import"
import "XMemory"

These two sentences

 Imported

Focus！！！！！！！！！！！！！！！！！！！！！！！！
！！！！！！！！！！！！！！！！！！！！！！！！
！！！！！！！！！！！！！！！！！！！！！！！！
！！！！！！！！！！！！！！！！！！！！！！！！
The software needs this permission
 "WRITE_EXTERNAL_STORAGE"
 Chinese in Andlua is
 1. Modify or delete the contents of your USB storage device

 You must have this permission, otherwise you will get stuck and crash back!
！！！！！！！！！！！！！！！！！！！！！！！！
！！！！！！！！！！！！！！！！！！！！！！！！
！！！！！！！！！！！！！！！！！！！！！！！！
！！！！！！！！！！！！！！！！！！！！！！！！
	REGION_C_BSS = 1, //  1. Cb
	REGION_C_HEAP,    //  2. Ch
	REGION_C_ALLOC,   //  3. Ca
	REGION_C_DATA,	//  4. Cd
	REGION_STACK,	 //  5. S
	REGION_BAD,	   //  6. B (V内存)
	REGION_JAVA_HEAP, //  7. Jh (慢)
	REGION_ANONY,	 //  8. A
	REGION_CODE_APP,  //  9. Xa
	REGION_CODE_SYS,  // 10. Xs


DWORD = 1, // 4-byte integer
 WORD, // 2-byte integer
 QWORD, // 8-byte long integer
 FLOAT, // single-precision floating-point number
 DOUBLE, // double precision floating point
 BYTE, // single byte
 HEX_L, // little-endian hexadecimal
 HEX_B // big endian hex
	
	The numbers represented by the types are from top to bottom
	1 2 3 4 5 6 7 8
]]


--One-click XS writing memory modification
内存修改={
目标程序 = "com.tencent.tmgp.pubgmhd",--Package names
内存范围 = "9", --Look at the table above (multiple memory ranges can be selected)
搜索数组 = {{9.2429214e18,4},{6.4503569e-10,4,4},{2.7891018e29,8,4},{7.5033516e28,12,4},{0.00016923042,16,4}}, --{{Initial value, type (see above table, fill in numbers)}, {value 1, offset value (see above table, fill in numbers), type (see above table, fill in numbers)},...} Support similar  Search in the range of 1~2 Modify array = {{0,0,4,0,0,36}} --{{Modify the value, offset value, type, modify a few (0 is all), whether to freeze (0 is not frozen, 1 is frozen), if the fifth parameter is frozen, set the freezing interval here (unit: microseconds)  }}
print(搜索写入(内存修改))--Get back
--Repeat it again. The sixth parameter to be modified is the freezing interval. The unit is microseconds (μs). 0 is not recommended (may be stuck)





--One-click access to search results
读取组={
目标程序 = "com.tencent.tmgp.pubgmhd",--Package names
内存范围 = "9", --Look at the table above (multiple memory ranges can be selected)
搜索数组 = {{9.2429214e18,4},{6.4503569e-10,4,4},{2.7891018e29,8,4},{7.5033516e28,12,4},{0.00016923042,16,4}}, --{{Initial value, type (see above table, fill in numbers)}, {value 1, offset value (see above table, fill in numbers), type (see above table, fill in numbers)},...} Support similar  Search in the range of 1~2 Read type = "1,2,3,4,5,6,7,8" --Corresponding to the above type table
}
print(读取搜索(读取组))--Read return value







--Write the value according to the memory address
写入地址(包名,数值,类型,地址) --The return value is whether the modification is successful

如

print(写入地址("com.tencent.tmgp.pubgmhd",100,1,0xC2379934)) --Returns whether the modification is successful






--Read the value according to the memory address

读取数值(包名,类型,地址) --The return value is the value read

如

print(读取数值("com.tencent.tmgp.pubgmhd",1,0xC2379934)) --The return value is the value read

--！！！ Reading the value temporarily does not support HEX_L type and HEX_B type






--Clear the freeze list (cancel all freezes)

清除所有冻结()

--(No return value)


