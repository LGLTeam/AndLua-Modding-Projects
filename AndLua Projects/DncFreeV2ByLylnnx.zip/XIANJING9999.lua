local L0_0, L1_1, L2_2, L3_3, L4_4, L5_5, L6_6, L7_7, L8_8, L9_9, L10_10, L11_11, L12_12, L14_13, L15_14, L16_15, L17_16, L18_17, L19_18, L20_19, L21_20, L22_21, L23_22, L24_23, L26_24, L27_25, L28_26, L30_27, L31_28, L32_29, L33_30, L34_31, L35_32, L36_33, L37_34, L38_35, L39_36, L40_37, L41_38, L42_39, L43_40, L44_41
L0_0 = {L1_1}
L1_1 = RelativeLayout
L0_0.id = "win_centerview"
L0_0.layout_weight = "1"
L0_0.layout_height = "-1"
centerView = L0_0
L0_0 = {L1_1, L2_2}
L1_1 = LinearLayout
L0_0.layout_width = "-1"
L0_0.layout_height = "-1"
L2_2 = {L3_3, L4_4}
L3_3 = CardView
L2_2.background = "f000000"
L2_2.id = "win_mainview"
L2_2.layout_width = "800"
L2_2.layout_height = "700"
L2_2.layout_margin = "5dp"
L2_2.CardElevation = "5dp"
L2_2.radius = 40
L4_4 = {
  L5_5,
  L6_6,
  L7_7,
  L8_8,
  L9_9,
  L10_10
}
L5_5 = LinearLayout
L4_4.orientation = "vertical"
L4_4.background = "res/dnc_2.png"
L6_6 = {L7_7, L8_8}
L7_7 = LinearLayout
L8_8 = {
  L9_9,
  L10_10,
  L11_11,
  L12_12
}
L9_9 = LinearLayout
L8_8.orientation = "horizontal"
L8_8.layout_height = "100"
L8_8.layout_width = "-1"
L8_8.background = "#FF0090FF"
L8_8.background = "#22FFFFFF"
L10_10 = {L11_11}
L11_11 = ImageView
L10_10.layout_width = "100"
L10_10.layout_height = "100"
L10_10.scaleType = "centerCrop"
L10_10.padding = "3dp"
L10_10.src = "res/dnc_1.png"
L10_10.layout_gravity = "left"
L10_10.ColorFilter = "#0"
L10_10.onClick = "changeWindow"
L11_11 = {L12_12}
L12_12 = TextView
L11_11.text = "t.me/XIANJING9999"
L11_11.id = "win_move"
L11_11.layout_width = "600"
L11_11.layout_height = "100"
L11_11.gravity = "center"
L11_11.textSize = "15"
L11_11.textColor = "#FF0000"
L12_12 = {L14_13}
L14_13 = ImageView
L12_12.layout_width = "100"
L12_12.layout_height = "100"
L12_12.scaleType = "centerCrop"
L12_12.padding = "3dp"
L12_12.src = "res/dnc_4.png"
L12_12.layout_gravity = "left"
L12_12.ColorFilter = "#0"
L12_12.onClick = "close"
L7_7 = {L8_8}
L8_8 = LinearLayout
L7_7.layout_height = "0.1%h"
L7_7.layout_width = "100%w"
L7_7.background = "#292929"
L8_8 = {L9_9, L10_10}
L9_9 = LinearLayout
L8_8.orientation = "horizontal"
L8_8.layout_height = "100"
L8_8.layout_width = "-1"
L8_8.background = "#22FFFFFF"
L10_10 = {L11_11}
L11_11 = Button
L10_10.id = "menu1"
L10_10.layout_height = "-1"
L10_10.layout_width = "-1"
L10_10.background = "#00ffffff"
L10_10.text = "PUBG Mobile Free V2"
L10_10.textColor = "#0000FF"
L10_10.textSize = "13"
L10_10.layout_weight = "2"
L9_9 = {L10_10, L11_11}
L10_10 = LinearLayout
L9_9.layout_width = "-1"
L9_9.background = "#22FFFFFF"
L11_11 = {L12_12}
L12_12 = TextView
L11_11.id = "jd"
L11_11.background = "#292929"
L11_11.layout_height = "3dp"
L11_11.layout_width = "0%w"
L10_10 = {L11_11}
L11_11 = PageView
L10_10.id = "pg"
L10_10.layout_width = "fill"
L10_10.layout_height = "fill"
L12_12 = {L14_13}
L14_13 = {
  L15_14,
  L16_15,
  L17_16
}
L15_14 = LinearLayout
L14_13.orientation = "vertical"
L16_15 = {L17_16}
L17_16 = LinearLayout
L16_15.layout_height = "0.1%h"
L16_15.layout_width = "100%w"
L16_15.background = "#292929"
L17_16 = {L18_17, L19_18}
L18_17 = ScrollView
L19_18 = {L20_19, L21_20}
L20_19 = LinearLayout
L19_18.layout_height = "-1"
L19_18.layout_width = "-1"
L19_18.orientation = "vertical"
L21_20 = {L22_21, L23_22}
L22_21 = LinearLayout
L21_20.id = "_drawer_header"
L21_20.layout_height = "-2"
L21_20.layout_width = "-1"
L21_20.orientation = "vertical"
L23_22 = {
  L24_23,
  L26_24,
  L27_25,
  L28_26,
  L30_27,
  L31_28,
  L32_29,
  L33_30,
  L34_31,
  L35_32,
  L36_33,
  L37_34,
  L38_35,
  L39_36,
  L40_37,
  L41_38,
  L42_39,
  L43_40,
  L44_41,
  {
    RadioButton,
    id = "smg1",
    text = "speed smg v1"
  },
  {
    RadioButton,
    id = "smg2",
    text = "speed smg v2"
  }
}
L24_23 = LinearLayout
L23_22.layout_height = "-1"
L23_22.layout_width = "-1"
L23_22.orientation = "vertical"
L26_24 = {
  L27_25,
  L28_26,
  L30_27
}
L27_25 = CardView
L26_24.layout_height = "80"
L26_24.layout_width = "match_parent"
L26_24.background = "0x00000000"
L26_24.layout_gravity = "center"
L28_26 = {L30_27}
L30_27 = TextView
L28_26.layout_height = "match_parent"
L28_26.gravity = "center"
L28_26.paddingLeft = "8"
L28_26.text = "Esp Circle"
L28_26.textColor = "#000000"
L30_27 = {L31_28}
L31_28 = Switch
L30_27.id = "circle"
L30_27.text = "                                                                                                               "
L30_27.layout_height = "match_parent"
L30_27.gravity = "center"
L30_27.layout_gravity = "right"
L27_25 = {L28_26}
L28_26 = TextView
L27_25.text = "Type     (Esp type)"
L28_26 = {L30_27}
L30_27 = RadioButton
L28_26.id = "type1"
L28_26.text = "Esp Type1                                                               "
L30_27 = {L31_28}
L31_28 = RadioButton
L30_27.id = "type2"
L30_27.text = "Esp Type2                                                               "
L31_28 = {
  L32_29,
  L33_30,
  L34_31
}
L32_29 = CardView
L31_28.layout_height = "80"
L31_28.layout_width = "match_parent"
L31_28.background = "0x00000000"
L31_28.layout_gravity = "center"
L33_30 = {L34_31}
L34_31 = TextView
L33_30.layout_height = "match_parent"
L33_30.gravity = "center"
L33_30.paddingLeft = "8"
L33_30.text = "Wallhack cpu 845"
L33_30.textColor = "#000000"
L34_31 = {L35_32}
L35_32 = Switch
L34_31.id = "wh"
L34_31.text = "                                                                                                               "
L34_31.layout_height = "match_parent"
L34_31.gravity = "center"
L34_31.layout_gravity = "right"
L32_29 = {L33_30}
L33_30 = TextView
L32_29.text = "Chams cpu 845    (Color Hacks)"
L33_30 = {L34_31}
L34_31 = RadioButton
L33_30.id = "offclr"
L33_30.text = "OFF"
L34_31 = {L35_32}
L35_32 = RadioButton
L34_31.id = "yellow"
L34_31.text = "chams yellow                                                                                                   "
L34_31.background = "#FFFF00"
L35_32 = {L36_33}
L36_33 = RadioButton
L35_32.id = "green"
L35_32.text = "chams green                                                                                                   "
L35_32.background = "#00FF00"
L36_33 = {L37_34}
L37_34 = RadioButton
L36_33.id = "red"
L36_33.text = "chams red                                                                                                   "
L36_33.background = "#FF0000"
L37_34 = {
  L38_35,
  L39_36,
  L40_37
}
L38_35 = CardView
L37_34.layout_height = "80"
L37_34.layout_width = "match_parent"
L37_34.background = "0x00000000"
L37_34.layout_gravity = "center"
L39_36 = {L40_37}
L40_37 = TextView
L39_36.layout_height = "match_parent"
L39_36.gravity = "center"
L39_36.paddingLeft = "8"
L39_36.text = "No Recoil"
L39_36.textColor = "#000000"
L40_37 = {L41_38}
L41_38 = Switch
L40_37.id = "recoil"
L40_37.text = "                                                                                                               "
L40_37.layout_height = "match_parent"
L40_37.gravity = "center"
L40_37.layout_gravity = "right"
L38_35 = {
  L39_36,
  L40_37,
  L41_38
}
L39_36 = CardView
L38_35.layout_height = "80"
L38_35.layout_width = "match_parent"
L38_35.background = "0x00000000"
L38_35.layout_gravity = "center"
L40_37 = {L41_38}
L41_38 = TextView
L40_37.layout_height = "match_parent"
L40_37.gravity = "center"
L40_37.paddingLeft = "8"
L40_37.text = "Anti Shake"
L40_37.textColor = "#000000"
L41_38 = {L42_39}
L42_39 = Switch
L41_38.id = "shake"
L41_38.text = "                                                                                                               "
L41_38.layout_height = "match_parent"
L41_38.gravity = "center"
L41_38.layout_gravity = "right"
L39_36 = {
  L40_37,
  L41_38,
  L42_39
}
L40_37 = CardView
L39_36.layout_height = "80"
L39_36.layout_width = "match_parent"
L39_36.background = "0x00000000"
L39_36.layout_gravity = "center"
L41_38 = {L42_39}
L42_39 = TextView
L41_38.layout_height = "match_parent"
L41_38.gravity = "center"
L41_38.paddingLeft = "8"
L41_38.text = "aimlock"
L41_38.textColor = "#000000"
L42_39 = {L43_40}
L43_40 = Switch
L42_39.id = "aimlock"
L42_39.text = "                                                                                                               "
L42_39.layout_height = "match_parent"
L42_39.gravity = "center"
L42_39.layout_gravity = "right"
L40_37 = {
  L41_38,
  L42_39,
  L43_40
}
L41_38 = CardView
L40_37.layout_height = "80"
L40_37.layout_width = "match_parent"
L40_37.background = "0x00000000"
L40_37.layout_gravity = "center"
L42_39 = {L43_40}
L43_40 = TextView
L42_39.layout_height = "match_parent"
L42_39.gravity = "center"
L42_39.paddingLeft = "8"
L42_39.text = "Magic Bullet"
L42_39.textColor = "#000000"
L43_40 = {L44_41}
L44_41 = Switch
L43_40.id = "magic"
L43_40.text = "                                                                                                               "
L43_40.layout_height = "match_parent"
L43_40.gravity = "center"
L43_40.layout_gravity = "right"
L41_38 = {
  L42_39,
  L43_40,
  L44_41
}
L42_39 = CardView
L41_38.layout_height = "80"
L41_38.layout_width = "match_parent"
L41_38.background = "0x00000000"
L41_38.layout_gravity = "center"
L43_40 = {L44_41}
L44_41 = TextView
L43_40.layout_height = "match_parent"
L43_40.gravity = "center"
L43_40.paddingLeft = "8"
L43_40.text = "Rapid Fire"
L43_40.textColor = "#000000"
L44_41 = {
  Switch
}
L44_41.id = "fstsht"
L44_41.text = "                                                                                                               "
L44_41.layout_height = "match_parent"
L44_41.gravity = "center"
L44_41.layout_gravity = "right"
L42_39 = {
  L43_40,
  L44_41,
  {
    SeekBar,
    id = "seekbar",
    background = "#ffffffff",
    layout_width = "match_parent",
    layout_height = "wrap_content",
    max = "9",
    progress = "0"
  }
}
L43_40 = LinearLayout
L42_39.layout_height = "wrap"
L42_39.layout_width = "fill"
L42_39.orientation = "horizontal"
L44_41 = {
  TextView
}
L44_41.text = "FOV (field of view)"
L44_41.background = "#ffffffff"
L43_40 = {L44_41}
L44_41 = TextView
L43_40.text = "smg     (speedhack Smg)"
L44_41 = {
  RadioButton
}
L44_41.id = "hallu"
L44_41.text = "OFF"
L10_10.pages = L12_12
winlay = L0_0
