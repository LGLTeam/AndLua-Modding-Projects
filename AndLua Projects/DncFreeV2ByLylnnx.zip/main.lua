require("import")
import("AndLua")
import("android.app.*")
import("android.os.*")
import("android.widget.*")
import("android.view.*")
import("layout2")
import("http")
import("android.graphics.PorterDuffColorFilter")
import("android.graphics.PorterDuff")
require("import")
import("android.app.*")
import("android.os.*")
import("android.widget.*")
import("android.view.*")
import("layout")
import("android.content.Context")
import("AndLua")
import("android.ontent.*")
import("android.provider.Settings")
import("android.net.Uri")
import("android.content.Intent")
import("android.content.pm.PackageManager")
import("android.graphics.PixelFormat")
import("android.content.Context")
if Build.VERSION.SDK_INT >= 19 then
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
end
activity.setTheme(android.R.style.Theme_DeviceDefault_Light)
activity.setContentView(loadlayout(layout2))
activity.ActionBar.hide()
function login.onClick()
  local L0_97
  L0_97 = username
  L0_97 = L0_97.text
  if L0_97 == "dnc6284" then
    activity.newActivity("dnc628191")
    activity.finish()
  else
    print("wrong password")
  end
end

