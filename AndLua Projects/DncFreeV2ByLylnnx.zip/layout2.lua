local L0_84, L1_85, L2_86, L3_87, L4_88, L5_89, L6_90, L7_91, L8_92, L9_93, L10_94, L11_95, L12_96
L0_84 = {L1_85, L2_86}
L1_85 = LinearLayout
L0_84.background = "dnc9784/dnc.png"
L0_84.layout_height = "fill"
L0_84.orientation = "vertical"
L0_84.layout_width = "fill"
L2_86 = {L3_87, L4_88}
L3_87 = RelativeLayout
L2_86.layout_width = "fill"
L2_86.layout_height = "fill"
L4_88 = {
  L5_89,
  L6_90,
  L7_91,
  L8_92,
  L9_93
}
L5_89 = LinearLayout
L4_88.layout_marginRight = "25dp"
L4_88.layout_marginLeft = "10dp"
L4_88.layout_marginTop = "250dp"
L4_88.id = "box"
L4_88.layout_width = "fill"
L4_88.layout_marginBottom = "50dp"
L4_88.background = "#FFFF00"
L4_88.layout_centerHorizontal = "true"
L4_88.padding = "15dp"
L4_88.orientation = "vertical"
L4_88.Elevation = "10dp"
L4_88.layout_height = "220dp"
L4_88.layout_width = "700"
L6_90 = {L7_91}
L7_91 = TextView
L6_90.textSize = "20sp"
L6_90.textColor = "0xFF0000FF"
L6_90.text = "t.me/XIANJING9999"
L6_90.layout_height = "60dp"
L6_90.gravity = "center"
L6_90.layout_width = "fill"
L7_91 = {L8_92}
L8_92 = EditText
L7_91.layout_width = "fill"
L7_91.layout_marginTop = "10dp"
L7_91.id = "username"
L7_91.hint = "enter password"
L8_92 = {L9_93}
L9_93 = TextView
L9_93 = {L10_94, L11_95}
L10_94 = CardView
L9_93.layout_width = "-1"
L9_93.layout_height = "50dp"
L11_95 = {L12_96}
L12_96 = TextView
L11_95.text = "Login"
L11_95.gravity = "center"
L11_95.layout_height = "-1"
L11_95.id = "login"
L11_95.layout_width = "-1"
return L0_84
