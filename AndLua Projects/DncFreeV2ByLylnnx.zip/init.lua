local L0_98, L1_99, L2_100, L3_101, L4_102, L5_103, L6_104, L7_105, L8_106
appname = "DnC Pubg Free V2"
appver = "v4"
packagename = "com.dnc.gratisv2"
theme = "Theme_DeviceDefault_Light_NoActionBar"
developer = "DnC"
description = "@AnimeCheat Telegram By Lylnnx"
debugmode = true
L0_98 = {
  L1_99,
  L2_100,
  L3_101,
  L4_102,
  L5_103,
  L6_104,
  L7_105,
  L8_106
}
L1_99 = "ACCESS_NETWORK_STATE"
L2_100 = "CHANGE_WIFI_STATE"
L3_101 = "INTERNET"
L4_102 = "READ_EXTERNAL_STORAGE"
L5_103 = "READ_PHONE_STATE"
L6_104 = "SYSTEM_ALERT_WINDOW"
L7_105 = "WRITE_EXTERNAL_STORAGE"
L8_106 = "WRITE_SETTINGS"
user_permission = L0_98
