local L0_68, L1_69, L2_70, L3_71, L4_72, L5_73, L6_74, L7_75, L8_76, L9_77, L10_78, L11_79, L12_80, L13_81, L14_82, L15_83
L0_68 = {
  L1_69,
  L2_70,
  L3_71,
  L4_72,
  L5_73,
  L6_74,
  L7_75,
  L8_76,
  L9_77,
  L10_78,
  L11_79,
  L12_80,
  L13_81,
  L14_82
}
L1_69 = LinearLayout
L0_68.orientation = "vertical"
L0_68.layout_width = "-1"
L0_68.layout_height = "-1"
L0_68.gravity = "center"
L0_68.background = "res/dnc_3.png"
L2_70 = {L3_71}
L3_71 = Button
L2_70.layout_width = "180dp"
L2_70.layout_height = "40dp"
L2_70.background = "#5fff9fff"
L2_70.textColor = "#ffff9fff"
L2_70.text = "START CHEAT"
L2_70.id = "dncstart"
L3_71 = {L4_72}
L4_72 = LinearLayout
L3_71.layout_width = "-1"
L3_71.layout_height = "10dp"
L3_71.gravity = "center"
L4_72 = {L5_73}
L5_73 = Button
L4_72.layout_width = "180dp"
L4_72.layout_height = "40dp"
L4_72.background = "#5fff9fff"
L4_72.textColor = "#ffff9fff"
L4_72.text = "START GAME"
L4_72.id = "dncgame"
L5_73 = {L6_74}
L6_74 = LinearLayout
L5_73.layout_width = "-1"
L5_73.layout_height = "10dp"
L5_73.gravity = "center"
L6_74 = {L7_75}
L7_75 = Button
L6_74.layout_width = "180dp"
L6_74.layout_height = "40dp"
L6_74.background = "#5fff9fff"
L6_74.textColor = "#ffff9fff"
L6_74.text = "TELEGRAM"
L6_74.id = "dnctelegram"
L7_75 = {L8_76}
L8_76 = LinearLayout
L7_75.layout_width = "-1"
L7_75.layout_height = "10dp"
L7_75.gravity = "center"
L8_76 = {L9_77}
L9_77 = Button
L8_76.layout_width = "180dp"
L8_76.layout_height = "40dp"
L8_76.background = "#5fff9fff"
L8_76.textColor = "#ffff9fff"
L8_76.text = "TELEGRAM CHANEL"
L8_76.id = "dncchanel"
L9_77 = {L10_78}
L10_78 = LinearLayout
L9_77.layout_width = "-1"
L9_77.layout_height = "10dp"
L9_77.gravity = "center"
L10_78 = {L11_79}
L11_79 = Button
L10_78.layout_width = "180dp"
L10_78.layout_height = "40dp"
L10_78.background = "#5fff9fff"
L10_78.textColor = "#ffff9fff"
L10_78.text = "TELEGRAM GROUP"
L10_78.id = "dncgroub"
L11_79 = {L12_80}
L12_80 = LinearLayout
L11_79.layout_width = "-1"
L11_79.layout_height = "10dp"
L11_79.gravity = "center"
L12_80 = {L13_81}
L13_81 = Button
L12_80.layout_width = "180dp"
L12_80.layout_height = "40dp"
L12_80.background = "#5fff9fff"
L12_80.textColor = "#ffff9fff"
L12_80.text = "YouTube CHANEL"
L12_80.id = "dncyt"
L13_81 = {L14_82}
L14_82 = LinearLayout
L13_81.layout_width = "-1"
L13_81.layout_height = "10dp"
L13_81.gravity = "center"
L14_82 = {L15_83}
L15_83 = TextView
L14_82.gravity = "center"
L14_82.textColor = "#ff6fffff"
L14_82.layout_marginTop = "150dp"
L14_82.text = [[





t.me/XIANJING9999


t.me/cheaterpedia]]
return L0_68
