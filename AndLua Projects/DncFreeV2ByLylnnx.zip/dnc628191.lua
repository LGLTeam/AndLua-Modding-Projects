require("import")
import("android.app.*")
import("android.os.*")
import("android.widget.*")
import("android.view.*")
import("AndLua")
import("http")
import("android.content.Context")
import("android.content.Intent")
import("android.net.Uri")
import("android.provider.Settings")
import("XIANJING9999")
import("dnc9999")
import("layout")
import("android.view.animation.DecelerateInterpolator")
import("com.androlua.Ticker")
import("android.animation.AnimatorSet")
import("android.animation.ObjectAnimator")
activity.setContentView(loadlayout(layout))
os.execute("su")
wmManager = activity.getSystemService(Context.WINDOW_SERVICE)
HasFocus = false
wmParams = WindowManager.LayoutParams()
wmParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
import("android.graphics.PixelFormat")
wmParams.format = PixelFormat.RGBA_8888
wmParams.flags = WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
wmParams.gravity = Gravity.LEFT | Gravity.TOP
wmParams.x = 333
wmParams.y = 333
wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT
wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT
mainWindow = loadlayout(winlay)
minWindow = loadlayout(minlay)
_ENV["控件圆角"](dncstart, 2684338175, 70)
_ENV["控件圆角"](dncgame, 2684338175, 70)
_ENV["控件圆角"](dnctelegram, 2684338175, 70)
_ENV["控件圆角"](dncchanel, 2684338175, 70)
_ENV["控件圆角"](dncgroub, 2684338175, 70)
_ENV["控件圆角"](dncyt, 2684338175, 70)
function checkRoot()
  if os.execute("su") == true then
    print("Has obtained root permissions and is ready for normal use")
    return
  else
    print("Cannot be used normally without obtaining root privileges")
    return
  end
end

print(checkRoot())
function dncstart.onClick()
  function RX()
    offclr.setChecked(true)
    type1.setChecked(true)
    hallu.setChecked(true)
    fstsht.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    fstsht.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    circle.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    circle.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    wh.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    wh.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    recoil.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    recoil.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    shake.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    shake.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    aimlock.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    aimlock.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    magic.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    magic.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    if Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this) then
      return false
    elseif Build.VERSION.SDK_INT < 23 then
      print("Sorry your phone doesn't support opening floating window")
      return nil
    else
      return true
    end
  end
  
  if RX() then
  else
    AlertDialog.Builder(this).setTitle("Unable to open floating window").setMessage("Need to give the application floating window permissions to open the function interface").setPositiveButton("Click Authorize floating window permissions", {
      onClick = function(A0_42)
        intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        intent.setData(Uri.parse("package:" .. activity.getPackageName()))
        activity.startActivityForResult(intent, 100)
      end
      
    }).show()
  end
  if HasLaunch == true then
    return
  else
    if Settings.canDrawOverlays(activity) then
      print("The application has successfully obtained the floating window permissions ")
    else
      print("Give application floating window permission to use ")
      intent = Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION")
      intent.setData(Uri.parse("package:" .. this.getPackageName()))
      this.startActivity(intent)
    end
    HasLaunch = true
    if ({
      pcall(function()
        wmManager.addView(mainWindow, wmParams)
      end
      )
    })[1] == false then
    end
  end
  function close(A0_43)
    HasLaunch = false
    wmManager.removeView(mainWindow)
  end
  
  isMax = true
  function changeWindow()
    if isMax == false then
      isMax = true
      wmManager.removeView(minWindow)
      wmManager.addView(mainWindow, wmParams)
    else
      isMax = false
      wmManager.removeView(mainWindow)
      wmManager.addView(minWindow, wmParams)
    end
  end
  
  function Win_minWindow.onClick(A0_44)
    changeWindow()
  end
  
  function Win_minWindow.OnTouchListener(A0_45, A1_46)
    if A1_46.getAction() == MotionEvent.ACTION_DOWN then
      firstX = A1_46.getRawX()
      firstY = A1_46.getRawY()
      wmX = wmParams.x
      wmY = wmParams.y
    elseif A1_46.getAction() == MotionEvent.ACTION_MOVE then
      wmParams.x = wmX + (A1_46.getRawX() - firstX)
      wmParams.y = wmY + (A1_46.getRawY() - firstY)
      wmManager.updateViewLayout(minWindow, wmParams)
    elseif A1_46.getAction() == MotionEvent.ACTION_UP then
    end
    return false
  end
  
  function win_move.OnTouchListener(A0_47, A1_48)
    if A1_48.getAction() == MotionEvent.ACTION_DOWN then
      firstX = A1_48.getRawX()
      firstY = A1_48.getRawY()
      wmX = wmParams.x
      wmY = wmParams.y
    elseif A1_48.getAction() == MotionEvent.ACTION_MOVE then
      wmParams.x = wmX + (A1_48.getRawX() - firstX)
      wmParams.y = wmY + (A1_48.getRawY() - firstY)
      wmManager.updateViewLayout(mainWindow, wmParams)
    elseif A1_48.getAction() == MotionEvent.ACTION_UP then
    end
    return true
  end
  
  winParams = win_mainview.getLayoutParams()
end

function menu1.onClick()
  pg.showPage(0)
end

pg.addOnPageChangeListener({
  onPageScrolled = function(A0_49, A1_50, A2_51)
    jd.setX(activity.getWidth() / 3.5 * (A1_50 + A0_49))
  end
  ,
  onPageSelected = function(A0_52)
    local L1_53
  end
  ,
  onPageScrollStateChanged = function(A0_54)
    local L1_55
  end
  
})
function dncgame.onClick()
  function RX1()
    if Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this) then
      return false
    elseif Build.VERSION.SDK_INT < 23 then
      print("Sorry your phone does not support turning on this feature ")
    end
  end
  
  if RX1() then
  elseif pcall(function()
    activity.getPackageManager().getPackageInfo("com.tencent.ig", 0)
  end
  ) then
    ycpd = true
    import("android.content.pm.PackageManager")
    packageName = "com.tencent.ig"
    manager = activity.getPackageManager()
    open = manager.getLaunchIntentForPackage(packageName)
    this.startActivity(open)
  else
    print("Detected that the game is not installed, please install it first")
  end
end

function dnctelegram.onClick()
  function RX2()
    if Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this) then
      return false
    elseif Build.VERSION.SDK_INT < 23 then
      print("Sorry your phone does not support turning on this feature ")
    end
  end
  
  if RX2() then
  else
    url = "https://t.me/XIANJING9999"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    print("t.me/XIANJING9999")
  end
end

function dncchanel.onClick()
  function RX3()
    if Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this) then
      return false
    elseif Build.VERSION.SDK_INT < 23 then
      print("Sorry your phone does not support turning on this feature ")
    end
  end
  
  if RX3() then
  else
    url = "https://t.me/cheaterpedia"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    print("join to get update cheats!!!")
  end
end

function dncgroub.onClick()
  function RX3()
    if Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this) then
      return false
    elseif Build.VERSION.SDK_INT < 23 then
      print("Sorry your phone does not support turning on this feature ")
    end
  end
  
  if RX3() then
  else
    url = "https://t.me/joinchat/J1FFCxTFvAkDDkMBq13p1g"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
  end
end

function dncyt.onClick()
  function RX3()
    if Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this) then
      return false
    elseif Build.VERSION.SDK_INT < 23 then
      print("Sorry your phone does not support turning on this feature ")
    end
  end
  
  if RX3() then
  else
    url = "https://www.youtube.com/channel/UClRxrbn-8NTojhssdPpqQqw"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
  end
end

function circle.OnCheckedChangeListener()
  if circle.checked then
    circle.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    circle.TrackDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/14'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/14'")
    circle.setTextColor(4278255360)
    print("Esp Circle On")
  else
    circle.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    circle.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/23'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/23'")
    circle.setTextColor(4278190080)
    print("Esp Circle Off")
  end
end

function type1.onClick()
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/25'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/25'")
  type2.setChecked(false)
  print("esp type 1")
end

function type2.onClick()
  type1.setChecked(false)
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/26'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/26'")
  print("esp type 2")
end

function wh.OnCheckedChangeListener()
  if wh.checked then
    wh.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    wh.TrackDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/18'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/18'")
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/10'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/10'")
    wh.setTextColor(4278255360)
    print("Wallhack On")
  else
    wh.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    wh.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/17'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/17'")
    wh.setTextColor(4278190080)
    print("Wallhack Off")
  end
end

function offclr.onClick()
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/22'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/22'")
  print("chams off")
  yellow.setChecked(false)
  green.setChecked(false)
  red.setChecked(false)
end

function yellow.onClick()
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/13'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/13'")
  print("chams yellow on")
  offclr.setChecked(false)
  green.setChecked(false)
  red.setChecked(false)
end

function green.onClick()
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/11'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/11'")
  print("chams green on")
  offclr.setChecked(false)
  yellow.setChecked(false)
  red.setChecked(false)
end

function red.onClick()
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/12'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/12'")
  print("chams red on")
  offclr.setChecked(false)
  yellow.setChecked(false)
  green.setChecked(false)
end

function recoil.OnCheckedChangeListener()
  if recoil.checked then
    recoil.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    recoil.TrackDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/21'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/21'")
    recoil.setTextColor(4278255360)
    print("No Recoil On")
  else
    recoil.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    recoil.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/20'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/20'")
    recoil.setTextColor(4278190080)
    print("No Recoil Off")
  end
end

function shake.OnCheckedChangeListener()
  if shake.checked then
    shake.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    shake.TrackDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/16'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/16'")
    shake.setTextColor(4278255360)
    print("Anti shake On")
  else
    shake.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    shake.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/15'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/15'")
    shake.setTextColor(4278190080)
    print("Anti shake Off")
  end
end

function aimlock.OnCheckedChangeListener()
  if aimlock.checked then
    aimlock.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    aimlock.TrackDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/08'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/08'")
    aimlock.setTextColor(4278255360)
    print("Aimlock On")
  else
    aimlock.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    aimlock.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/09'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/09'")
    aimlock.setTextColor(4278190080)
    print("Aimlock Off")
  end
end

function magic.OnCheckedChangeListener()
  if magic.checked then
    magic.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    magic.TrackDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/19'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/19'")
    magic.setTextColor(4278255360)
    print("Magic Bullet On")
  else
    magic.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    magic.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/19'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/19'")
    magic.setTextColor(4278190080)
    print("Magic Bullet Off")
  end
end

seekbar.setOnSeekBarChangeListener({
  onStartTrackingTouch = function()
    local L0_56, L1_57
  end
  ,
  onStopTrackingTouch = function()
    local L0_58, L1_59
  end
  ,
  onProgressChanged = function(A0_60, A1_61)
    if A1_61 == 0 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/27'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/27'")
    end
    if A1_61 == 1 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/28'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/28'")
    end
    if A1_61 == 2 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/29'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/29'")
    end
    if A1_61 == 3 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/30'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/30'")
    end
    if A1_61 == 4 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/31'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/31'")
    end
    if A1_61 == 5 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/32'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/32'")
    end
    if A1_61 == 6 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/34'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/34'")
    end
    if A1_61 == 7 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/35'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/35'")
    end
    if A1_61 == 8 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/36'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/36'")
    end
    if A1_61 == 9 then
      os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/37'")
      Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/37'")
    end
  end
  
})
function fstsht.OnCheckedChangeListener()
  if fstsht.checked then
    fstsht.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    fstsht.TrackDrawable.setColorFilter(PorterDuffColorFilter(4278255360, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/38'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/38'")
    print("Rapid Fire On")
  else
    fstsht.ThumbDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    fstsht.TrackDrawable.setColorFilter(PorterDuffColorFilter(4294901760, PorterDuff.Mode.SRC_ATOP))
    os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/39'")
    Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/39'")
    print("Rapid Fire Off")
  end
end

function hallu.onClick()
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/40'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/40'")
  print("off speed smg")
  smg1.setChecked(false)
  smg2.setChecked(false)
end

function smg1.onClick()
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/41'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/41'")
  print("speed smg v1")
  hallu.setChecked(false)
  smg2.setChecked(false)
end

function smg2.onClick()
  os.execute("su -c 'chmod 777 /data/data/com.dnc.gratisv2/files/dnc1363/42'")
  Runtime.getRuntime().exec("su -c '/data/data/com.dnc.gratisv2/files/dnc1363/42'")
  print("speed smg v2")
  hallu.setChecked(false)
  smg1.setChecked(false)
end

