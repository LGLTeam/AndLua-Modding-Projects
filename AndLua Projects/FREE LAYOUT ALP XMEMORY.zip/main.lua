require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "AndLua"
import "http"
import "android.content.Context"
import "android.content.Intent"
import "android.provider.Settings"
import "android.net.Uri"
import "android.content.pm.PackageManager"
import "android.graphics.Typeface"
import "Hz_Vip_Menu"
import "XMemory"
import "Hz_Vip_Ly"
载入页面(Hz_Vip_Ly)

HzNoRootZ=activity.getSystemService(Context.WINDOW_SERVICE)
HasFocus=false
WmHz =WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then WmHz.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
else WmHz.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
import "android.graphics.PixelFormat"
WmHz.format =PixelFormat.RGBA_8888
WmHz.flags=WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
WmHz.gravity = Gravity.LEFT| Gravity.TOP
WmHz.x = 333
WmHz.y = 333
WmHz.width = WindowManager.LayoutParams.WRAP_CONTENT
WmHz.height = WindowManager.LayoutParams.WRAP_CONTENT
mainWindow = loadlayout(winlay)
minWindow = loadlayout(minlay)
function close(v)
HasLaunch = false
HzNoRootZ.removeView(mainWindow)
end
isMax=true
function changeWindow()
if isMax==false then
isMax=true
HzNoRootZ.removeView(minWindow)
HzNoRootZ.addView(mainWindow,WmHz)
else
isMax=false
HzNoRootZ.removeView(mainWindow)
HzNoRootZ.addView(minWindow,WmHz)
end end
function Win_minWindow.onClick(v) changeWindow() end
function Win_minWindow.OnTouchListener(v,event)
if event.getAction()==MotionEvent.ACTION_DOWN then
firstX=event.getRawX()
firstY=event.getRawY()
wmX=WmHz.x
wmY=WmHz.y
elseif event.getAction()==MotionEvent.ACTION_MOVE then
WmHz.x=wmX+(event.getRawX()-firstX)
WmHz.y=wmY+(event.getRawY()-firstY)
HzNoRootZ.updateViewLayout(minWindow,WmHz)
elseif event.getAction()==MotionEvent.ACTION_UP then
end return false end
function win_move1.OnTouchListener(v,event)
if event.getAction()==MotionEvent.ACTION_DOWN then
firstX=event.getRawX()
firstY=event.getRawY()
wmX=WmHz.x
wmY=WmHz.y
elseif event.getAction()==MotionEvent.ACTION_MOVE then
WmHz.x=wmX+(event.getRawX()-firstX)
WmHz.y=wmY+(event.getRawY()-firstY)
HzNoRootZ.updateViewLayout(mainWindow,WmHz)
elseif event.getAction()==MotionEvent.ACTION_UP then
end return true end
function win_move2.OnTouchListener(v,event)
if event.getAction()==MotionEvent.ACTION_DOWN then
firstX=event.getRawX()
firstY=event.getRawY()
wmX=WmHz.x
wmY=WmHz.y
elseif event.getAction()==MotionEvent.ACTION_MOVE then
WmHz.x=wmX+(event.getRawX()-firstX)
WmHz.y=wmY+(event.getRawY()-firstY)
HzNoRootZ.updateViewLayout(mainWindow,WmHz)
elseif event.getAction()==MotionEvent.ACTION_UP then
end return true end
pg.addOnPageChangeListener{
onPageScrolled=function(a,b,c)
end,
onPageSelected=function(page)
end,
onPageScrollStateChanged=function(state)
end,}

showhack.onClick=function() 
if HasLaunch==true then return else
if Settings.canDrawOverlays(activity) then else intent=Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
intent.setData(Uri.parse("package:" .. this.getPackageName()));  this.startActivity(intent); end HasLaunch=true
local ret={pcall(function() HzNoRootZ.addView(mainWindow,WmHz) end)}
if ret[1]==false then end end import "java.io.*" file,err=io.open("/data/data/t.me.andluaofficial/files/HzVipMemory.lua")
if err==nil then 打开app("t.me.andluaofficial") else end end

function startgame.onClick()
gamepackage = "package_name_game_nya"
this.startActivity(activity.getPackageManager().getLaunchIntentForPackage(gamepackage));
end

function about.onClick()
activity.newActivity("Hz_Vip_About")
activity.finish()
end

function CircleButton(view,InsideColor,radiu,InsideColor1)
import "android.graphics.drawable.GradientDrawable"
drawable = GradientDrawable()
drawable.setShape(GradientDrawable.RECTANGLE)
drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
drawable.setColor(InsideColor)
drawable.setStroke(3, InsideColor1)
view.setBackgroundDrawable(drawable)
end
CircleButton(win_mainview,0x3f000000,0,0xffffffff)
CircleButton(showhack,0x3f000000,0,0xfff800ff)
CircleButton(startgame,0x3f000000,0,0xfff800ff)
CircleButton(about,0x3f000000,0,0xffffffff)

win_move1.setTypeface(Typeface.DEFAULT_BOLD)



-- CONTOH VALUE

-- 内存修改={
-- 目标程序 = "com.tencent.ig",   < PACKAGE NAME
-- 内存范围 = "6",< INI REGION
-- 搜索数组 = {{1073741824,1},{537149475,-60,1}},   < {{Value Target Want To Make Hack,Type},{Value,Offset,Type}
-- 修改数组 = {{1125515264,0,1,0,0,0}}    < {Edit Value , Get Results 0 is Edit All, Type , Freeze , Freeze Inteval}
-- }
-- print(搜索写入(内存修改)) -- INI JANGAN DI REMOVE



---    REGION_C_BSS = 1, //  1. Cb
---    REGION_C_HEAP,   //  2. Ch
---	REGION_C_ALLOC,   //  3. Ca
---	REGION_C_DATA,	//  4. Cd
---	REGION_STACK,	 //  5. S
---	REGION_BAD,	   //  6. B 
---	REGION_JAVA_HEAP, //  7. Jh
---	REGION_ANONY,	 //  8. A
---	REGION_CODE_APP,  //  9. Xa
---	REGION_CODE_SYS,  // 10. Xs


--- INI TYPE VALUE

---	DWORD = 1,		//
---	WORD,	= 2		 // 
---	QWORD, = 3			// 
---	FLOAT,	= 4		// 
---	DOUBLE, = 5	   	// 
---	BYTE,	= 6 	//
---	HEX_L,	= 7		// 
---	HEX_B	= 8	 	//


--id="hz1" --/Less-Recoil
function hz1.OnCheckedChangeListener()
if hz1.checked then
内存修改={
目标程序 = "com.tencent.ig", 
内存范围 = "4",
搜索数组 = {{-298841599,1},{-308339980,-16,1},{-310113741,16,1}}, 
修改数组 = {{0,0,1,0,0,0}}}
print(搜索写入(内存修改))
print("LESS RECOIL ON")
else
内存修改={
目标程序 = "com.tencent.ig", 
内存范围 = "4",
搜索数组 = {{0,1},{-308339980,-16,1},{-310113741,16,1}}, 
修改数组 = {{-298841599,0,1,0,0,0}}}
print(搜索写入(内存修改))
print("LESS RECOIL OFF")
end
end

function hz2.OnCheckedChangeListener()
if hz2.checked then

else

end
end

function hz3.OnCheckedChangeListener()
if hz3.checked then

else

end
end

function hz4.OnCheckedChangeListener()
if hz4.checked then

else

end
end

function hz5.OnCheckedChangeListener()
if hz5.checked then

else

end
end





