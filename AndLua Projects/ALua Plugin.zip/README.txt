--[[
List Feature Plugin :
Toaster(message,backgroundcolor,sizetext) = Make Toast In Down
pop_up = Show Animation Pop Up
buttonView = Retangle Button
GetAppInfo(Package App) = Show Info Version Name App 
customToast(message,background,text color,evelation,radius) = Showing Customization Toast
goURL(URL) = Open Link In Chrome Only
goTele(Id) = Open Chenel/Account/Group With Telegram
CustomButton = Make Retangle Button
Blinker(id,color1,color2,color3,color4) = Make Animation Color Gradient
Launcher(Package App) = Launching App With Package App
Unzipper(path.zip,output path,filename extract,password if have) = Extract One Files In Zip
Unzippers(path.zip,output path,password if have) = Extract All Files In Zip

Credit By
- @AndLuaOfficial

Admin :
- @hz_mods1
- @ZPictYT

]]

--Put This On main.lua
import "ALua"

-- Testing 
Toaster("✔ Success","#FF3C8BDA","15sp")
Blinker(backgrounds,0xff566270,0xffE71D36,0xff353866,0xFFAA97FF)