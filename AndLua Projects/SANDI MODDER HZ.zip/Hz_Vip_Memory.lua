
function HzNoRoot(Hz_B,HackZoneMod)
Hz_C=activity.getLuaDir(Hz_B)
os.execute("chmod 777 "..Hz_C)
Runtime.getRuntime().exec(""..Hz_C)
MD提示(HackZoneMod,"#6f003e7c","#ffffffff","9","45")
end

function HzRoot(Hz_B,HackZoneMod)
Hz_C=activity.getLuaDir(Hz_B)
os.execute("su -c chmod 777 "..Hz_C)
Runtime.getRuntime().exec("su -c "..Hz_C)
MD提示(HackZoneMod,"#6f003e7c","#ffffffff","9","45")
end

function antiban.onClick()
os.remove("/sdcard/Android/data/com.tencent.ig/cache")
os.remove("/sdcard/Android/data/com.tencent.ig/files/tbslog")
os.remove("/sdcard/Android/data/com.tencent.ig/files/cacheFile.txt")
os.remove("/sdcard/Android/data/com.tencent.ig/files/login-identifier.txt")
os.remove("/sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs")
end

function hz_vip1.OnCheckedChangeListener()
if hz_vip1.checked then
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/antena_on","Antena Head On")
else
HzNoRoot("Vip_Hz_Mods/Hz_Vip_Vz/antena_off","Antena Head Off")
end
end





