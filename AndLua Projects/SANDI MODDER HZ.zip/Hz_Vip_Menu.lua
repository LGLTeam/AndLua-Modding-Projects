minlay={
LinearLayout;
layout_width="40dp";
layout_height="40dp";
{
ImageView;
layout_width="60dp";
src="icon.png";
id="Win_minWindow";
layout_height="60dp";
};
};

winlay={
LinearLayout,
layout_width="-1",
layout_height="-1",
background="transparent",
{
CardView,
id="win_mainview",
layout_width="60%w", 
layout_height="30%h";
layout_margin="5dp",
background="#ff000000";
CardElevation="5dp",
{
LinearLayout;
orientation="vertical";
layout_width="fill_parent";
background="transparent",
{
LinearLayout;
layout_width="fill_parent";
background="transparent";
{
LinearLayout;
orientation="horizontal";
layout_height="fill";
layout_width="-1";
gravity="center_horizontal|center_vertical";
background="transparent",
{
ImageView,
translationX="-20dp";
layout_height="5.5%h";
layout_width="10%w";
colorFilter="#ffffffff";
src="Vip_Hz_Mods/Hz_Vip_Min.png",
onClick="changeWindow",
},

{
LinearLayout;
orientation="vertical";
gravity="center_horizontal|center_vertical";
{
TextView;
text="SANDI MODDER";
id="win_move1",
textSize="16dp";
textColor="#ffffff";
},
{
TextView;
text="Nama Game Nya";
id="win_move2",
textSize="10dp";
textColor="#ffffff";
},
};

{
ImageView,
translationX="20dp";
layout_height="5.5%h";
layout_width="10%w";
colorFilter="#ffffffff";
src="Vip_Hz_Mods/Hz_Vip_Close.png",
onClick="close",
},
};
};
{
LinearLayout;
orientation="horizontal";
layout_height="20";
layout_width="-1";
};
{
PageView,
id="pg",
layout_width="fill",
layout_height="fill",
pages={
{
LinearLayout;
orientation="vertical";
{
ScrollView;
layout_width="fill_parent";
layout_height="fill_parent",
layout_gravity="center_horizontal";
{
LinearLayout;
layout_height="-1";
layout_width="-1";
orientation="vertical";
{
LinearLayout;
id="_drawer_header";
layout_height="-2";
layout_width="-1";
orientation="vertical";
{
LinearLayout;
layout_height="-1";
layout_width="-1";
orientation="vertical";
{
LinearLayout;
orientation="horizontal";
layout_height="20";
layout_width="-1";
};

{
Button;
layout_width="-1";
id="antiban";
textColor="#280045";
text="DELETE LOGS";
};
{
Switch;
layout_width="-1";
id="hz_vip1";
textColor="0xffffffff";
text="   ANTENA HEAD";
textSize="12";
};
{
Switch;
layout_width="-1";
id="hz_vip2";
textColor="0xffffffff";
text="   FITURE 2";
textSize="12";
};
{
Switch;
layout_width="-1";
id="hz_vip3";
textColor="0xffffffff";
text="   FITURE 3";
textSize="12";
};
{
Switch;
layout_width="-1";
id="hz_vip4";
textColor="0xffffffff";
text="   FITURE 4";
textSize="12";
};








};
};
};
};
};
};
};
};
};
}