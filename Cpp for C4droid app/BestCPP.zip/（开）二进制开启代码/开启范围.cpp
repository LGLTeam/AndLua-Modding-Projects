#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
//killGG();
PACKAGENAME *bm="com.tencent.ig";
BypassGameSafe();
SetSearchRange(ANONY);//设置搜索内存范围
SetTextColor(COLOR_PINK);//设置文字颜色
puts("开始内存搜索...");
MemorySearch(bm,"30.5",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"9.20161819458",-32,&gs,FLOAT);
MemoryOffset(bm,"-1.31859207153",-28,&gs,FLOAT);
MemoryOffset(bm,"0.00009203507",-24,&gs,FLOAT);
MemoryOffset(bm,"23.0",-8,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"250",0,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"25",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1091779028",-28,&gs,DWORD);
MemoryOffset(bm,"-1079457888",-24,&gs,DWORD);
MemoryOffset(bm,"952173300",-20,&gs,DWORD);
MemoryOffset(bm,"1102577664",-4,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("第二步...");
MemoryWrite(bm,"250",0,FLOAT);
puts("修改完成");
ClearResults();
}