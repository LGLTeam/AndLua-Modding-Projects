#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
//killGG();
PACKAGENAME *bm="com.tencent.ig";
BypassGameSafe();
SetSearchRange(B_BAD);//设置搜索内存范围
SetTextColor(COLOR_PINK);//设置文字颜色
puts("开始内存搜索...");
MemorySearch(bm,"2",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"3.76158192e-37",-100,&gs,FLOAT);
MemoryOffset(bm,"1.39125666e-19",-116,&gs,FLOAT);
MemoryOffset(bm,"2.37548923492",-132,&gs,FLOAT);
MemoryOffset(bm,"3.37548875809",-148,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"120",0,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"2",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"5.4049168e21",-12,&gs,FLOAT);
MemoryOffset(bm,"5.8910587e-42",-48,&gs,FLOAT);
MemoryOffset(bm,"2.25000238419",-36,&gs,FLOAT);
MemoryOffset(bm,"6.9419832e-29",-24,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第二步...");
MemoryWrite(bm,"120",0,FLOAT);
puts("修改完成");
ClearResults();


puts("开始内存搜索...");
MemorySearch(bm,"2",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"0.01799999923",12,&gs,FLOAT);
MemoryOffset(bm,"0.02000427246",20,&gs,FLOAT);
MemoryOffset(bm,"0.5869140625",28,&gs,FLOAT);
MemoryOffset(bm,"0.11401367188",32,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第三步...");
MemoryWrite(bm,"120",0,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"2",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"2.7550649e-40",-48,&gs,FLOAT);
MemoryOffset(bm,"2.37561130524",-36,&gs,FLOAT);
MemoryOffset(bm,"1.0842027e-19",-24,&gs,FLOAT);
MemoryOffset(bm,"4.7777084e21",-12,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第四步...");
MemoryWrite(bm,"120",0,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"2",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"280498336",-152,&gs,DWORD);
MemoryOffset(bm,"1.3912555e-19",-140,&gs,FLOAT);
MemoryOffset(bm,"34",-128,&gs,DWORD);
MemoryOffset(bm,"1.662336e-19",-116,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第五步...");
MemoryWrite(bm,"120",0,FLOAT);
puts("修改完成");
ClearResults();
}