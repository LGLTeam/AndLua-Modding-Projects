#include "MemoryTools.h"
int main(int argc,char **argv)
{
killGG();
int gs;//用来存储数据个数
void *jg;
PACKAGENAME *bm="com.tencent.ig";//软件包名
//注意这里要用指针,就是那个*号,不可以去掉

BypassGameSafe();
SetSearchRange(C_DATA);
puts("开始内存搜索...");
MemorySearch(bm,"-2.786982e28",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"-6.1719541e27",12,&gs,FLOAT);
MemoryOffset(bm,"-2.7250567e28",24,&gs,FLOAT);
MemoryOffset(bm,"6.1629883e-33",36,&gs,FLOAT);
MemoryOffset(bm,"-2.2673448e24",48,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"0",0,FLOAT);
puts("修改完成");
ClearResults();
}