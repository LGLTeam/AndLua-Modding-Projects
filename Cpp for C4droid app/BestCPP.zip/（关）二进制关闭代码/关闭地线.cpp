#include "MemoryTools.h"
int main(int argc,char **argv)
{
killGG();
int gs;//用来存储数据个数
void *jg;
PACKAGENAME *bm="com.tencent.ig";//软件包名
//注意这里要用指针,就是那个*号,不可以去掉

BypassGameSafe();
SetSearchRange(A_ANONMYOUS);
puts("开始内存搜索...");
MemorySearch(bm,"-99999",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"3.7252903e-7",-12,&gs,FLOAT);
MemoryOffset(bm,"14.01080131531",-24,&gs,FLOAT);
MemoryOffset(bm,"-0.06997600198",-36,&gs,FLOAT);
MemoryOffset(bm,"13.19364356995",-48,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"-1.68741369247",0,FLOAT);
puts("修改完成");
ClearResults();
}