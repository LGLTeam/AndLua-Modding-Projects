#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
//killGG();
PACKAGENAME *bm="com.tencent.ig";
BypassGameSafe();
SetSearchRange(B_BAD);//设置搜索内存范围
SetTextColor(COLOR_PINK);//设置文字颜色
puts("开始内存搜索...");
MemorySearch(bm,"2",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1194347034",12,&gs,DWORD);
MemoryOffset(bm,"8204",24,&gs,DWORD);
MemoryOffset(bm,"1194344477",36,&gs,DWORD);
MemoryOffset(bm,"279019536",48,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"8195",0,DWORD);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"2",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1194346762",12,&gs,DWORD);
MemoryOffset(bm,"1.2611686e-44",24,&gs,FLOAT);
MemoryOffset(bm,"7.1746481e-43",36,&gs,FLOAT);
MemoryOffset(bm,"393216",48,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("第二步...");
MemoryWrite(bm,"8195",0,DWORD);
puts("修改完成");
ClearResults();
}