#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
//killGG();
PACKAGENAME *bm="com.tencent.ig";
BypassGameSafe();
SetSearchRange(B_BAD);//设置搜索内存范围
SetTextColor(COLOR_PINK);//设置文字颜色
puts("开始内存搜索...");
MemorySearch(bm,"9999",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"9.8090893e-45",-120,&gs,FLOAT);
MemoryOffset(bm,"4.7604163e21",-132,&gs,FLOAT);
MemoryOffset(bm,"2.2960275e-41",-144,&gs,FLOAT);
MemoryOffset(bm,"4.7961574e21",-156,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"2",0,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"9999",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1.1202013e-19",-140,&gs,FLOAT);
MemoryOffset(bm,"2.2963078e-41",-152,&gs,FLOAT);
MemoryOffset(bm,"46.0078125",-164,&gs,FLOAT);
MemoryOffset(bm,"1.0842022e-19",-176,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第二步...");
MemoryWrite(bm,"2",0,FLOAT);
puts("修改完成");
ClearResults();
}