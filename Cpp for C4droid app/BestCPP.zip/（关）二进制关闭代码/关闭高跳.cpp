#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
//killGG();
PACKAGENAME *bm="com.tencent.ig";
BypassGameSafe();
SetSearchRange(A_ANONMYOUS);//设置搜索内存范围
SetTextColor(COLOR_PINK);//设置文字颜色
puts("开始内存搜索...");
MemorySearch(bm,"0.57357645035",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"55",-4,&gs,FLOAT);
MemoryOffset(bm,"443",-12,&gs,FLOAT);
MemoryOffset(bm,"35",-16,&gs,FLOAT);
MemoryOffset(bm,"3",-20,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"1",-20,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"0.57357645035",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"55",-4,&gs,FLOAT);
MemoryOffset(bm,"2500",-12,&gs,FLOAT);
MemoryOffset(bm,"35",-16,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第二步...");
MemoryWrite(bm,"443",-12,FLOAT);
puts("修改完成");
ClearResults();
}