#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
//killGG();
PACKAGENAME *bm="com.tencent.ig";
BypassGameSafe();
SetSearchRange(B_BAD);//设置搜索内存范围
SetTextColor(COLOR_PINK);//设置文字颜色
puts("开始内存搜索...");
MemorySearch(bm,"1179663",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1661534230",20,&gs,DWORD);
MemoryOffset(bm,"1376273",40,&gs,DWORD);
MemoryOffset(bm,"1080035863",60,&gs,DWORD);
MemoryOffset(bm,"112",80,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"8200",96,DWORD);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"8",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1661767680",12,&gs,DWORD);
MemoryOffset(bm,"921774",24,&gs,DWORD);
MemoryOffset(bm,"536887312",36,&gs,DWORD);
MemoryOffset(bm,"921795",48,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("第二步...");
MemoryWrite(bm,"8201",0,DWORD);
puts("修改完成");
ClearResults();


puts("开始内存搜索...");
MemorySearch(bm,"6",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"-2145714158",-64,&gs,DWORD);
MemoryOffset(bm,"1638421",-48,&gs,DWORD);
MemoryOffset(bm,"281215004",-32,&gs,DWORD);
MemoryOffset(bm,"1835036",-16,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
Print();
puts("第三步...");
MemoryWrite(bm,"8200",0,DWORD);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"7",&gs,DWORD);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1.1496253e-41",-72,&gs,FLOAT);
MemoryOffset(bm,"1.1479437e-41",-48,&gs,FLOAT);
MemoryOffset(bm,"720901",-32,&gs,DWORD);
MemoryOffset(bm,"1.0102003e-39",-16,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第四步...");
MemoryWrite(bm,"8200",0,DWORD);
puts("修改完成");
ClearResults();
}