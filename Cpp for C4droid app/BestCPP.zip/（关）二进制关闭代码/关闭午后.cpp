#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
//killGG();
PACKAGENAME *bm="com.tencent.ig";
BypassGameSafe();
SetSearchRange(C_DATA);//设置搜索内存范围
SetTextColor(COLOR_PINK);//设置文字颜色
puts("开始内存搜索...");
MemorySearch(bm,"0",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"-6.1719541e27",12,&gs,FLOAT);
MemoryOffset(bm,"-2.7250567e28",24,&gs,FLOAT);
MemoryOffset(bm,"6.1629883e-33",36,&gs,FLOAT);
MemoryOffset(bm,"-2.2673448e24",48,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"-2.786982e28",0,FLOAT);
puts("修改完成");
ClearResults();

puts("开始内存搜索...");
MemorySearch(bm,"-2.8111605430681e+28",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"-3.7444097189856e+28",8,&gs,FLOAT);
MemoryOffset(bm,"0",12,&gs,FLOAT);
MemoryOffset(bm,"128",16,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第二步...");
MemoryWrite(bm,"-1.1144501557583e+28",12,FLOAT);
puts("修改完成");
ClearResults();


puts("开始内存搜索...");
MemorySearch(bm,"-6.1549453500004e+27",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"1.8638965755821e-20",8,&gs,FLOAT);
MemoryOffset(bm,"0",12,&gs,FLOAT);
MemoryOffset(bm,"0",20,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第三步...");
MemoryWrite(bm,"-1.1144501557583e+28",12,FLOAT);
puts("修改完成");
ClearResults();
}