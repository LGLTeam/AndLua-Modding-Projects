#include "MemoryTools.h"
int main(int argc,char **argv)
{
killGG();
int gs;//用来存储数据个数
void *jg;
PACKAGENAME *bm="com.tencent.ig";//软件包名
//注意这里要用指针,就是那个*号,不可以去掉

BypassGameSafe();
SetSearchRange(ANONY);
puts("开始内存搜索...");
MemorySearch(bm,"650",&gs,FLOAT);//搜索内存
printf("共搜索%d个数据\n",gs);
MemoryOffset(bm,"0.61770325899",12,&gs,FLOAT);
MemoryOffset(bm,"13.27982902527",24,&gs,FLOAT);
MemoryOffset(bm,"-0.10547397286",36,&gs,FLOAT);
MemoryOffset(bm,"23.52585792542",48,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
Print();
puts("第一步...");
MemoryWrite(bm,"18.38787841797",0,FLOAT);
puts("修改完成");
ClearResults();
}