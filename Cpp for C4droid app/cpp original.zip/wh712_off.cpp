#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
PACKAGENAME *bm="com.pubg.krmobile";
BypassGameSafe();
SetSearchRange(B_BAD);
MemorySearch(bm,"130",&gs,FLOAT);
MemoryOffset(bm,"value",offset,&gs,DWORD);
MemoryOffset(bm,"value",offset,&gs,DWORD);
MemoryOffset(bm,"value",offset,&gs,DWORD);
MemoryWrite(bm,"2",0,FLOAT);
BypassGameSafe();
SetSearchRange(B_BAD);
MemorySearch(bm,"130",&gs,DWORD);
MemoryOffset(bm,"value",offset,&gs,DWORD);
MemoryOffset(bm,"value",offset,&gs,DWORD);
MemoryOffset(bm,"value",offset,&gs,DWORD);
MemoryWrite(bm,"2",0,DWORD);
puts("HZ MODS PRO");
ClearResults();
}