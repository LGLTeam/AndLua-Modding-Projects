#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
PACKAGENAME *bm="com.tencent.ig";
BypassGameSafe();
SetSearchRange(C_DATA); 
MemorySearch(bm,"0",&gs,DWORD); 
MemoryOffset(bm,"-286131696",4,&gs,DWORD);
MemoryOffset(bm,"-290108736",-4,&gs,DWORD);
MemoryOffset(bm,"-286131696",-8,&gs,DWORD);
MemoryWrite(bm,"1324366404",0,DWORD);
ClearResults();
BypassGameSafe();
SetSearchRange(C_DATA); 
MemorySearch(bm,"1152327680",&gs,DWORD); 
MemoryOffset(bm,"-301852144",12,&gs,DWORD); 
MemoryOffset(bm,"-301778416",8,&gs,DWORD); 
MemoryOffset(bm,"-1011613696",-8,&gs,DWORD); 
MemoryWrite(bm,"953267991",0,DWORD);
ClearResults();
BypassGameSafe();
SetSearchRange(C_DATA); 
MemorySearch(bm,"0",&gs,DWORD); 
MemoryOffset(bm,"-286131696",4,&gs,DWORD); 
MemoryOffset(bm,"-285.980.089",8,&gs,DWORD); 
MemoryWrite(bm,"1324366404",0,DWORD);
puts("MADE BY HZ MODS : SHARE WITH CREDITS");
ClearResults();
}