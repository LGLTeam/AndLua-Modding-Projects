#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
PACKAGENAME *bm="com.pubg.krmobile";
BypassGameSafe();
SetSearchRange(C_DATA);
MemorySearch(bm,"-298841599",&gs,DWORD);
MemoryOffset(bm,"-308339980",-16,&gs,DWORD);
MemoryOffset(bm,"-310113741",16,&gs,DWORD);
MemoryWrite(bm,"0",0,DWORD);
puts("HZ MODS PRO ");
ClearResults();
}