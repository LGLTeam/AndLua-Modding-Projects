#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;
PACKAGENAME *bm="com.pubg.krmobile";
BypassGameSafe();
SetSearchRange(B_BAD);
MemorySearch(bm,"8201",&gs,DWORD);
MemoryOffset(bm,"1194344475",-4,&gs,DWORD);
MemoryOffset(bm,"1194379806",4,&gs,DWORD);
MemoryWrite(bm,"7",0,DWORD);
BypassGameSafe();
SetSearchRange(B_BAD);
MemorySearch(bm,"8200",&gs,DWORD);
MemoryOffset(bm,"1661698074",-4,&gs,DWORD);
MemoryOffset(bm,"1194344475",4,&gs,DWORD);
MemoryWrite(bm,"7",0,DWORD);
puts("HZ MODS PRO");
ClearResults();
}