#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;//用来存储数据个数
void *jg;
PACKAGENAME *bm="com.tencent.igce";//软件包名
//注意这里要用指针,就是那个*号,不可以去掉
BypassGameSafe();//跳过游戏保护
SetSearchRange(B_BAD);//搜索内存
puts("开始内存搜索...");
MemorySearch(bm,"65541",&gs,DWORD);//主特征
MemoryOffset(bm,"292622411",8,&gs,DWORD);
MemoryOffset(bm,"6",16,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
MemoryWrite(bm,"8200",16,DWORD);
puts("660AIE高清人物绿色关闭成功");

}