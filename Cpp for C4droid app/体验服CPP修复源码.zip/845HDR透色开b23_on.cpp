#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;//用来存储数据个数
void *jg;
PACKAGENAME *bm="com.tencent.igce";//软件包名
//注意这里要用指针,就是那个*号,不可以去掉
BypassGameSafe();//跳过游戏保护
SetSearchRange(B_BAD);//搜索内存
puts("开始内存搜索...");
MemorySearch(bm,"1.1202056e-19",&gs,FLOAT);//主特征
MemoryOffset(bm,"3.7615819e-37",8,&gs,FLOAT);
MemoryOffset(bm,"2",108,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
MemoryWrite(bm,"100",108,FLOAT);
puts("845透视第一步");

MemorySearch(bm,"2.4382593e-43",&gs,FLOAT);//主特征
MemoryOffset(bm,"5.8910587e-42",8,&gs,FLOAT);
MemoryOffset(bm,"2",56,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
MemoryWrite(bm,"100",56,FLOAT);
puts("845透视第二步");

MemorySearch(bm,"1.1202011e-19",&gs,FLOAT);//主特征
MemoryOffset(bm,"3.7615819e-37",16,&gs,FLOAT);
MemoryOffset(bm,"2",124,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
MemoryWrite(bm,"99999",124,FLOAT);
puts("845透视防闪第一步");

MemorySearch(bm,"8.4077908e-45",&gs,FLOAT);//主特征
MemoryOffset(bm,"3.7615819e-37",20,&gs,FLOAT);
MemoryOffset(bm,"2",144,&gs,FLOAT);
printf("共偏移%d个数据\n",gs);
MemoryWrite(bm,"99999",144,FLOAT);
puts("845透视防闪第二步");

MemorySearch(bm,"1194379840",&gs,DWORD);//主特征
MemoryOffset(bm,"1662812168",-24,&gs,DWORD);
MemoryOffset(bm,"8200",-12,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
MemoryWrite(bm,"-1",-24,DWORD);
puts("845HDR人物透色开启成功");

}