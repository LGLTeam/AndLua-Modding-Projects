#include "MemoryTools.h"
int main(int argc,char **argv)
{
int gs;//用来存储数据个数
void *jg;
PACKAGENAME *bm="com.tencent.igce";//软件包名
//注意这里要用指针,就是那个*号,不可以去掉
BypassGameSafe();//跳过游戏保护
SetSearchRange(C_ALLOC);//搜索内存
puts("开始内存搜索...");
MemorySearch(bm,"1",&gs,DWORD);//主特征
MemoryOffset(bm,"222",8,&gs,DWORD);
MemoryOffset(bm,"64",16,&gs,DWORD);
MemoryOffset(bm,"223",28,&gs,DWORD);
printf("共偏移%d个数据\n",gs);
MemoryWrite(bm,"61",16,DWORD);
puts("联发科P22人物透视开启成功");

}